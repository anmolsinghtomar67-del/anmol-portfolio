# Personal Portfolio Website

A responsive personal portfolio built with HTML, CSS, JavaScript, Python, Flask, and SQLite.

## Features
- Home, About, Skills, Projects, Education, and Contact sections
- Responsive mobile navigation
- Contact form with server-side validation
- Contact messages saved to a local SQLite database
- Resume download endpoint

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment (recommended):

   **Windows**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

5. Start the website:
   ```bash
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

## Personalize before publishing
- The site is personalized for Anmol Singh Tomar. Update any profile details as needed.
- GitHub profile URL was not provided; add it in `templates/index.html` when available. Review the introduction and skills to match your current experience.
- Replace sample project descriptions with your actual work and add real repository links.
- Add your PDF CV at `static/resume.pdf`.
- Do not publish private contact details unless you want recruiters to see them.

## Contact form
The form posts to `/contact`. Messages are stored in `data/portfolio.db`.
For a public production deployment, add spam protection, HTTPS, secure configuration,
and a privacy notice. Do not expose the SQLite database or admin credentials publicly.
