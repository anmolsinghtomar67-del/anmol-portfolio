from flask import Flask, render_template, request, jsonify, send_from_directory
import sqlite3
from pathlib import Path

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "portfolio.db"
DB_PATH.parent.mkdir(exist_ok=True)

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

@app.route("/")
def home():
    return render_template("index.html")

@app.post("/contact")
def contact():
    data = request.get_json(silent=True) or request.form
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip()
    message = str(data.get("message", "")).strip()

    if not name or not email or not message:
        return jsonify(success=False, message="Please fill in all fields."), 400
    if "@" not in email or "." not in email.split("@")[-1]:
        return jsonify(success=False, message="Please enter a valid email address."), 400

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "INSERT INTO messages (name, email, message) VALUES (?, ?, ?)",
            (name, email, message)
        )
    return jsonify(success=True, message="Thanks! Your message has been received.")

@app.route("/resume")
def resume():
    resume_dir = BASE_DIR / "static"
    resume_file = resume_dir / "resume.pdf"
    if not resume_file.exists():
        return "Add your CV as static/resume.pdf to enable resume downloads.", 404
    return send_from_directory(resume_dir, "resume.pdf", as_attachment=True)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
